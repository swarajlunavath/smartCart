package com.webser.smartcarttest;


public class Barcode {

    String barcodeId;
    String barcode;
    String name;
    String price;
    String weight;
    public Barcode(){

    }

    public Barcode(String barcodeId, String barcode, String name, String price, String weight) {
        this.barcodeId = barcodeId;
        this.barcode = barcode;
        this.name = name;
        this.price = price;
        this.weight = weight;
    }

    public String getBarcodeId() {
        return barcodeId;
    }

    public String getBarcode() {
        return barcode;
    }

    public String getName() {
        return name;
    }

    public String getPrice() {
        return price;
    }

    public String getWeight() {
        return weight;
    }
}

package com.webser.smartcarttest;

public class Cart {

    String itemId;
    String name;
    String price;
    public Cart(){


    }

    public Cart(String itemId, String name, String price) {
        this.itemId = itemId;
        this.name = name;
        this.price = price;
    }

    public String getItemId() {
        return itemId;
    }

    public String getName() {
        return name;
    }

    public String getPrice() {
        return price;
    }
}

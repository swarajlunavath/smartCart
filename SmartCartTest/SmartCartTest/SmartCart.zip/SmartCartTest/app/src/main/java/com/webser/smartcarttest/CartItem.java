package com.webser.smartcarttest;

import android.app.Activity;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;

import java.util.List;




public class CartItem extends ArrayAdapter<Cart> {
    private Activity context;
    private List<Cart> cartItem;
    public CartItem(Activity context,List<Cart> cartItem ){

        super(context,R.layout.list, cartItem);
        this.context=context;
        this.cartItem=cartItem;
    }

    @NonNull
    @Override
    public View getView(int position, @Nullable View convertView, @NonNull ViewGroup parent) {
        LayoutInflater inflater = context.getLayoutInflater();
        View listViewItem = inflater.inflate(R.layout.list, null,true);

        TextView textViewName=listViewItem.findViewById(R.id.textView5);
        TextView textViewPrice=listViewItem.findViewById(R.id.textView6);
        Cart cart= cartItem.get(position);


        textViewName.setText(cart.getName());
        textViewPrice.setText(cart.getPrice());

        return listViewItem;
    }
}

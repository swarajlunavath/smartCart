package com.webser.smartcarttest;


import android.app.Activity;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;

import java.util.List;

public class CartList extends ArrayAdapter<Barcode> {
    private Activity context;
    private List<Barcode> cartList;
    public CartList(Activity context,List<Barcode> cartList ){

        super(context,R.layout.list, cartList);
        this.context=context;
        this.cartList=cartList;
    }

    @NonNull
    @Override
    public View getView(int position, @Nullable View convertView, @NonNull ViewGroup parent) {
        LayoutInflater inflater = context.getLayoutInflater();
        View listViewItem = inflater.inflate(R.layout.list, null,true);

        TextView textViewName=listViewItem.findViewById(R.id.textView5);
        TextView textViewPrice=listViewItem.findViewById(R.id.textView6);
        Barcode barcode= cartList.get(position);


        textViewName.setText(barcode.getName());
        textViewPrice.setText(barcode.getPrice());

        return listViewItem;
    }
}

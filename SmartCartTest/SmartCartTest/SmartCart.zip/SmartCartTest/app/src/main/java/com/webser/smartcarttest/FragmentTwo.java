package com.webser.smartcarttest;


import android.os.Bundle;

import androidx.annotation.NonNull;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

import com.google.android.material.floatingactionbutton.FloatingActionButton;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.util.ArrayList;
import java.util.List;


/**
 * A simple {@link Fragment} subclass.
 */
public class FragmentTwo extends Fragment {


    public FragmentTwo() {
        // Required empty public constructor
    }

    DatabaseReference databaseBarcode;
    DatabaseReference databaseCart;
    ListView listView;
    TextView textView;
    List<Barcode> cartList;
    List<Cart> cartItem;
    FloatingActionButton addItem;
    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        View v= inflater.inflate(R.layout.fragment_fragment_two, container, false);
         textView=v.findViewById(R.id.textView3);
        listView=v.findViewById(R.id.list_item);
        cartList=new ArrayList<>();
        cartItem=new ArrayList<>();
        databaseBarcode= FirebaseDatabase.getInstance().getReference("items");
        databaseCart=FirebaseDatabase.getInstance().getReference("carts/carts_id_1");
        addItem=v.findViewById(R.id.add_item);
     /*   Bundle bundle=getArguments();
        if (bundle!=null){
           final String id=bundle.getString("id");
            textView.setText(id);
            databaseBarcode.addValueEventListener(new ValueEventListener() {
                @Override
                public void onDataChange(@NonNull DataSnapshot dataSnapshot) {

                    for (DataSnapshot barcodeSnapshot : dataSnapshot.getChildren()){


                        Barcode barcode=barcodeSnapshot.getValue(Barcode.class);
                            String barcode2=barcode.barcode;
                            if ( id.equals(barcode2)) {
                                cartList.add(barcode);
                            }

                    }

                    CartList adapter = new CartList(getActivity(), cartList);
                    listView.setAdapter(adapter);
                }

                @Override
                public void onCancelled(@NonNull DatabaseError databaseError) {

                }
            });

        }
        addItem.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                ScannedBarcode scannedBarcode=new ScannedBarcode();
                FragmentManager  manager=getFragmentManager();
                manager.beginTransaction().replace(R.id.main_container, scannedBarcode).commit();

            }
        });


      */
        return v;
    }

  /* @Override
    public void onStart() {
        super.onStart();
        databaseBarcode.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
               cartList.clear();
                for (DataSnapshot barcodeSnapshot : dataSnapshot.getChildren()){


                    Barcode barcode=barcodeSnapshot.getValue(Barcode.class);

                    cartList.add(barcode);


                }

                CartList adapter = new CartList(getActivity(), cartList);
                listView.setAdapter(adapter);
            }

            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {

            }
        });
    }*/

    @Override
    public void onStart() {
        super.onStart();

        databaseCart.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {


                for (DataSnapshot cartSnapshot: dataSnapshot.getChildren()){
                    Cart cart1=cartSnapshot.getValue(Cart.class);
                    cartItem.add(cart1);
                }


                CartItem adapter1=new CartItem(getActivity(), cartItem);
                listView.setAdapter(adapter1);
            }

            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {

            }
        });

        Bundle bundle=getArguments();
        if (bundle!=null){
            final String id=bundle.getString("id");


            textView.setText(id);
            cartitem(id);



        }
        addItem.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                ScannedBarcode scannedBarcode=new ScannedBarcode();
                FragmentManager  manager=getFragmentManager();
                manager.beginTransaction().replace(R.id.main_container, scannedBarcode).commit();

            }
        });




    }

    private void cartitem(final String id) {

        databaseBarcode.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {

                String name;
                String price;
                for (DataSnapshot barcodeSnapshot : dataSnapshot.getChildren()){


                    Barcode barcode=barcodeSnapshot.getValue(Barcode.class);
                    String barcode2=barcode.barcode;
                    name=barcode.name;
                    price=barcode.price;

                    if ( id.equals(barcode2)) {

                        String itemId= databaseCart.push().getKey();//add total here later
                        Cart cart= new Cart(itemId, name, price);
                        databaseCart.child(id).setValue(cart);
                        Toast.makeText(getActivity(), "added to cart", Toast.LENGTH_SHORT).show();


                        //cartList.add(barcode);
                    }
                    else{
                        Toast.makeText(getActivity(), "item id not found in database", Toast.LENGTH_SHORT).show();
                    }

                }

                // CartList adapter = new CartList(getActivity(), cartList);
                //listView.setAdapter(adapter);
            }

            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {

            }
        });
    }
}

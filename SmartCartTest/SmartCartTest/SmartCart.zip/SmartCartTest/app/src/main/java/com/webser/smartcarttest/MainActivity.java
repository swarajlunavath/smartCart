package com.webser.smartcarttest;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;
import androidx.fragment.app.FragmentTransaction;

import android.content.Intent;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;

import com.google.android.material.bottomnavigation.BottomNavigationView;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;

public class MainActivity extends AppCompatActivity {


    FragmentManager manager;
    FragmentTransaction transaction;
    private BottomNavigationView mainbottomnav;
    private FragmentTwo fragmentTwo;
    private ScannedBarcode scannedBarcodeActivity;
    private Payment payment;
    private FirebaseAuth mAuth;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        mAuth = FirebaseAuth.getInstance();

        mainbottomnav = findViewById(R.id.mainBottomnav);

        scannedBarcodeActivity = new ScannedBarcode();
        fragmentTwo = new FragmentTwo();
        payment = new Payment();



        mainbottomnav.setOnNavigationItemSelectedListener(new BottomNavigationView.OnNavigationItemSelectedListener() {
            @Override
            public boolean onNavigationItemSelected(@NonNull MenuItem menuItem) {

                switch(menuItem.getItemId()) {


                    case R.id.bottom_action_scan : replaceFragment(scannedBarcodeActivity);
                        return true;
                    case R.id.bottom_action_cart : replaceFragment(fragmentTwo);
                        return true;
                    case R.id.bottom_action_payment :replaceFragment(payment);
                        return true;
                    default:return false;

                }

            }
        });

    }

    private void replaceFragment(Fragment fragment){
        FragmentTransaction fragmentTransaction = getSupportFragmentManager().beginTransaction();
        fragmentTransaction.replace(R.id.main_container,fragment);
        fragmentTransaction.commit();
    }

    @Override
    protected void onStart() {
        super.onStart();

        FirebaseUser currentUser = FirebaseAuth.getInstance().getCurrentUser();
        if(currentUser==null){
           sendToLogin();
        }


    }



    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.menu, menu);

        return true;
    }

    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item) {
        switch (item.getItemId()){
            case R.id.btn_logout: logOut();
            return true;

            default:return false;
        }
    }

    private void logOut() {

        mAuth.signOut();
        sendToLogin();
    }



    private void sendToLogin() {
        Intent intent=new Intent(MainActivity.this,login.class);
        startActivity(intent);
        finish();

    }
}

package com.webser.smartcarttest;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

public class PaymentDone extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_payment_done);
    }
}

package com.webser.smartcarttest;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ProgressBar;
import android.widget.Toast;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;

public class createActivity extends AppCompatActivity {


   private EditText reg_email_text;
   private EditText reg_pass_text;
    private EditText reg_confirmpass_text;

    private Button reg_create;
   private ProgressBar reg_progress;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_create);
        final FirebaseAuth mAuth = FirebaseAuth.getInstance();
        reg_email_text=findViewById(R.id.createEmail);
        reg_pass_text=findViewById(R.id.createPass);
        reg_create=findViewById(R.id.createBtn);
        reg_progress=findViewById(R.id.createProgress);
        reg_confirmpass_text=findViewById(R.id.createConfirm);

        reg_create.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                String email=reg_email_text.getText().toString();
                String pass=reg_pass_text.getText().toString();
                String confirm_pass=reg_confirmpass_text.getText().toString();

                if (!TextUtils.isEmpty(email) && !TextUtils.isEmpty(pass) && !TextUtils.isEmpty(confirm_pass)){

                    if (pass.equals(confirm_pass)){
                        reg_progress.setVisibility(View.VISIBLE);

                    mAuth.createUserWithEmailAndPassword(email, pass).addOnCompleteListener(new OnCompleteListener<AuthResult>() {
                        @Override
                        public void onComplete(@NonNull Task<AuthResult> task) {

                        if (task.isSuccessful() ){
                            sendToMain();

                        }else{
                            String error = task.getException().getMessage();
                            Toast.makeText(createActivity.this, "Error"+error, Toast.LENGTH_SHORT).show();
                        }


                        reg_progress.setVisibility(View.INVISIBLE);
                        }


                    });
                    }else{
                        Toast.makeText(createActivity.this, "Both Passwords doesn't match", Toast.LENGTH_SHORT).show();
                    }



                }

            }
        });
    }


    @Override
    protected void onStart() {
        super.onStart();
        FirebaseUser currentUser = FirebaseAuth.getInstance().getCurrentUser();
        if(currentUser!=null){
            sendToMain();
        }

    }

    private void sendToMain() {

        Intent intent=new Intent(createActivity.this,MainActivity.class);
        startActivity(intent);
        finish();
    }
}
